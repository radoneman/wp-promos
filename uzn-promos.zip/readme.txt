=== Promos, Sweepstakes, Giveaways ===
Contributors: radoneman
Donate link: 
Tags: promos, sweepstakes, giveaways
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Run promos, sweepstakes, giveaways and collect user data. 

== Description ==

Run promos, sweepstakes, giveaways and collect user data. 

Use custom HTML template. 

The plugin uses separate tables so it will not interfere with WP tables.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the plugin from Promos on left menu

== Frequently Asked Questions ==

= Placeholder for question =

Placeholder for answer

== Screenshots ==

1. Register page on public area
2. Listing promos in admin area
3. Edit promo in admin area
4. View applications in admin area

== Changelog ==

= 1.0 =
* First release.