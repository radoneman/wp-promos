<div class="text-center">
	<h1>Promo Not Found</h1>
	<h2>Sorry but this promotion is no longer active.</h2>
	<br><br>
	<a class="btn btn-primary" href="<?php echo home_url(); ?>">Continue to Homepage</a>
	<br><br>
</div>

