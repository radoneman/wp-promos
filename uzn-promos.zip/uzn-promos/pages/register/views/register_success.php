<div class="text-center">
	<h1>Congratulations!</h1>
	<?php echo $promo->text_success; ?>
	<br><br>
	<a class="btn btn-primary" href="<?php echo home_url(); ?>">Continue to Homepage</a>
	<br><br>
</div>

