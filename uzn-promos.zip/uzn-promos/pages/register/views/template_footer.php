					</div>
				</div>
			</div>

		</div>
	</div>
	<div class="footer">
		<div class="footer-links">
			<div class="container text-center">
				<ul class="clearfix">
					<li><a href="<?php echo home_url(); ?>">Home</a></li>
					<li><a href="<?php echo site_url('link1'); ?>">Link 1</a></li>
					<li><a href="<?php echo site_url('link2'); ?>">Link 2</a></li>
				</ul>
			</div>
		</div>
	</div>

<!-- google -->
<!-- end:google -->

</body>
</html>