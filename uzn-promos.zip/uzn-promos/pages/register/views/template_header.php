<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="cleartype" content="on">
	<title>Promos</title>
	<meta name="description" content="">
	<meta name="keywords" content="">
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,500' rel='stylesheet' type='text/css'>
	<link href="<?php echo UZN_PROMOS_PLUGIN_DIR_URL; ?>assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php echo UZN_PROMOS_PLUGIN_DIR_URL; ?>assets/css/main.css" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<div class="content">
		<div class="container">

			<div class="row">
				<div class="col-md-18 col-md-offset-3">

					<div class="header">
						<a class="logo" href="#"><img class="img-responsive" src="<?php echo UZN_PROMOS_PLUGIN_DIR_URL; ?>assets/img/logo.png" alt=""></a>
					</div>
					<div class="popup">